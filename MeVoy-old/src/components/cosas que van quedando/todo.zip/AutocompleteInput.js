import React, { useRef, useEffect } from "react";
import { useJsApiLoader } from "@react-google-maps/api";
import { MAP_LIBS, MAP_LOADER_ID } from "../googleMapsConfig";

export default function AutocompleteInput({ placeholder, value, onChange }) {
  const { isLoaded, loadError } = useJsApiLoader({
    id: MAP_LOADER_ID,
    googleMapsApiKey: process.env.REACT_APP_GOOGLE_MAPS_API_KEY,
    libraries: MAP_LIBS,
  });

  const inputRef = useRef(null);
  const autocompleteRef = useRef(null);

  useEffect(() => {
  if (
    isLoaded &&
    !loadError &&
    inputRef.current &&
    !autocompleteRef.current
  ) {
    autocompleteRef.current = new window.google.maps.places.Autocomplete(
      inputRef.current,
      {
        types: ["geocode"],
        componentRestrictions: { country: "ar" }
      }
    );
    autocompleteRef.current.setFields(["formatted_address", "geometry"]);
    autocompleteRef.current.addListener("place_changed", () => {
      const place = autocompleteRef.current.getPlace();
      if (place && place.formatted_address) onChange(place);
    });
  }
}, [isLoaded, loadError, onChange]);


  if (loadError) return <p>Error cargando Autocomplete</p>;
  if (!isLoaded) return <p>Cargando Autocomplete…</p>;

  // Estilos inline para garantizar bordes redondeados, tipografía y márgenes
  const inputStyle = {
    width: '100%',
    padding: '0.5rem',
    margin: '0.5rem 0',
    border: '1px solid #ccc',
    borderRadius: '0.5rem',
    fontFamily: 'inherit',
    fontSize: '1rem',
  };

  return (
    <input
      ref={inputRef}
      type="text"
      placeholder={placeholder}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      style={inputStyle}
    />
  );
}
