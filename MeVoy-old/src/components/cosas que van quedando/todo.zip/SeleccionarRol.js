// src/components/SeleccionarRol.js
import React from "react";
import { doc, setDoc } from "firebase/firestore";
import { db } from "../firebase";

function SeleccionarRol({ usuario, setRol }) {
  const elegirRol = async (rolElegido) => {
    try {
      await setDoc(
        doc(db, "usuarios", usuario.uid),
        {
          rol: rolElegido
        },
        { merge: true }      // ← conserva todos los campos previos
      );

      localStorage.setItem("rolSeleccionado", rolElegido);
      setRol(rolElegido);
    } catch (error) {
      console.error("Error al guardar el rol:", error);
      alert("Hubo un problema al guardar tu rol.");
    }
  };

  return (
  <div className="text-center p-4">
    <h2 className="text-xl font-bold mb-4">¿Cómo querés usar la app?</h2>
    <div style={{ display: 'flex', justifyContent: 'center', gap: '2rem' }}>
      <span
        onClick={() => elegirRol("conductor")}
        style={{
          cursor: 'pointer',
          color: '#444',
          fontWeight: 500,
          fontSize: '1.05rem',
          position: 'relative',
          transition: 'color 0.2s ease'
        }}
        onMouseEnter={(e) => (e.target.style.color = '#2563eb')}
        onMouseLeave={(e) => (e.target.style.color = '#444')}
      >
        Conducir
        <span style={{
          display: 'block',
          height: '2px',
          backgroundColor: '#2563eb',
          position: 'absolute',
          bottom: -4,
          left: 0,
          right: 0,
          transform: 'scaleX(0)',
          transition: 'transform 0.3s ease',
        }}
        className="underline-hover" />
      </span>

      <span
        onClick={() => elegirRol("viajero")}
        style={{
          cursor: 'pointer',
          color: '#444',
          fontWeight: 500,
          fontSize: '1.05rem',
          position: 'relative',
          transition: 'color 0.2s ease'
        }}
        onMouseEnter={(e) => (e.target.style.color = '#2563eb')}
        onMouseLeave={(e) => (e.target.style.color = '#444')}
      >
        Viajar
        <span style={{
          display: 'block',
          height: '2px',
          backgroundColor: '#2563eb',
          position: 'absolute',
          bottom: -4,
          left: 0,
          right: 0,
          transform: 'scaleX(0)',
          transition: 'transform 0.3s ease',
        }}
        className="underline-hover" />
      </span>
    </div>
  </div>
);
}

export default SeleccionarRol;
