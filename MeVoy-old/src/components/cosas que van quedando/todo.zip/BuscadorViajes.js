// src/components/BuscadorViajes.js
import React, { useState } from "react";
import DetalleViaje from "./DetalleViaje";
import AutocompleteInput from "./AutocompleteInput";

/**
 * Componente BuscadorViajes
 * Props:
 * - viajes: Array de objetos { id, origen, destino, fecha (ISO), asientos, origenCoords, destinoCoords, horario }
 * - usuario: Objeto usuario con al menos uid, o null si no hay sesión
 * - onReservar: Función (viajeId) => Promise<void> que ejecuta la reserva
 */
export default function BuscadorViajes({ viajes, usuario, onReservar }) {
  const [origen, setOrigen] = useState("");
  const [destino, setDestino] = useState("");
  const [fecha, setFecha] = useState("");
  const [pasajeros, setPasajeros] = useState(1);
  const [resultados, setResultados] = useState([]);
  const [detalle, setDetalle] = useState(null);
  const [loading, setLoading] = useState(false);

  // Mismo estilo que en NuevoViaje
  const inputStyle = {
    width: '100%',
    padding: '0.5rem',
    margin: '0.5rem 0',
    border: '1px solid #ccc',
    borderRadius: '0.5rem',
    fontFamily: 'inherit',
    fontSize: '1rem',
  };

  // Filtrar viajes según criterios
  const buscar = () => {
    const dateISO = fecha ? new Date(fecha).toISOString().slice(0, 10) : null;
    const origText = typeof origen === 'object' ? origen.formatted_address : origen;
    const destText = typeof destino === 'object' ? destino.formatted_address : destino;
    const filt = viajes.filter(v => {
      const matchOrigen = origText
        ? v.origen.toLowerCase().includes(origText.toLowerCase())
        : true;
      const matchDestino = destText
        ? v.destino.toLowerCase().includes(destText.toLowerCase())
        : true;
      const matchFecha = dateISO
        ? v.fecha.slice(0, 10) === dateISO
        : true;
      const matchAsientos = v.asientos >= pasajeros;
      return matchOrigen && matchDestino && matchFecha && matchAsientos;
    });
    setResultados(filt);
  };

  // Confirmar reserva
  const confirmarReserva = async (viajeId) => {
    if (!usuario) {
      alert("Iniciá sesión para reservar");
      return;
    }
    if (typeof onReservar !== 'function') {
      console.error('onReservar no está definido');
      return;
    }
    setLoading(true);
    try {
      await onReservar(viajeId);
      alert('¡Reserva exitosa!');
      setDetalle(null);
      buscar(); // refresca resultados con nuevos asientos
    } catch (err) {
      console.error(err);
      alert('Hubo un problema al reservar');
    } finally {
      setLoading(false);
    }
  };

  if (detalle) {
    return (
      <DetalleViaje
        viaje={detalle}
        pasajeros={pasajeros}
        onClose={() => setDetalle(null)}
        onReservar={() => confirmarReserva(detalle.id)}
        loading={loading}
      />
    );
  }

  return (
    <div style={{ padding: '1rem', backgroundColor: 'white', borderRadius: '0.5rem', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
      <h2 style={{ fontSize: '1.5rem', fontWeight: 'bold', marginBottom: '1rem' }}>Buscar Viajes</h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem', marginBottom: '1.5rem' }}>
        <AutocompleteInput
          placeholder="Origen"
          value={typeof origen === 'object' ? origen.formatted_address : origen}
          onChange={setOrigen}
          className=""
          style={inputStyle}
        />
        <AutocompleteInput
          placeholder="Destino"
          value={typeof destino === 'object' ? destino.formatted_address : destino}
          onChange={setDestino}
          className=""
          style={inputStyle}
        />
        <input
          type="date"
          value={fecha}
          onChange={e => setFecha(e.target.value)}
          style={inputStyle}
        />
        <select
          value={pasajeros}
          onChange={e => setPasajeros(Number(e.target.value))}
          style={inputStyle}
        >
          {[...Array(6)].map((_, i) => (
            <option key={i+1} value={i+1}>{i+1} pasajero{ i>0 && 's' }</option>
          ))}
        </select>
      </div>

      <button
        onClick={buscar}
        style={{
          backgroundColor: '#2563eb',
          color: 'white',
          padding: '0.75rem',
          border: 'none',
          borderRadius: '0.375rem',
          fontFamily: 'inherit',
          width: '100%',
          cursor: 'pointer',
        }}
      >
        Buscar
      </button>

      <div style={{ marginTop: '1.5rem' }}>
        {resultados.length === 0 ? (
          <p style={{ color: '#4b5563' }}>No hay viajes disponibles.</p>
        ) : (
          resultados.map(v => (
            <div
              key={v.id}
              style={{
                backgroundColor: 'white',
                borderRadius: '0.5rem',
                boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
                padding: '1rem',
                marginBottom: '1rem'
              }}
            >
              <p style={{ fontWeight: 500 }}>{v.origen} → {v.destino}</p>
              <p style={{ fontSize: '0.875rem' }}>{new Date(v.fecha).toLocaleString()}</p>
              <p style={{ fontSize: '0.875rem' }}>Asientos: {v.asientos}</p>
              <div style={{ display: 'flex', gap: '0.5rem', marginTop: '0.5rem' }}>
                <button
                  onClick={() => setDetalle(v)}
                  style={{ padding: '0.5rem 0.75rem', borderRadius: '0.375rem', backgroundColor: '#3b82f6', color: 'white', border: 'none', cursor: 'pointer' }}
                >
                  Ver detalles
                </button>
                <button
                  onClick={() => setDetalle(v)}
                  style={{ padding: '0.5rem 0.75rem', borderRadius: '0.375rem', backgroundColor: '#10b981', color: 'white', border: 'none', cursor: 'pointer' }}
                >
                  Reservar
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}