import React, { useState, useEffect } from "react";
import { useUser } from "../contexts/UserContext";
import { db } from "../firebase";
import { doc, getDoc, setDoc } from "firebase/firestore";

export default function PerfilConductor2() {
  const { usuario } = useUser();

  const [whatsapp, setWhatsapp] = useState("");
  const [fechaNacimiento, setFechaNacimiento] = useState("");
  const [descripcion, setDescripcion] = useState("");
  const [modeloVehiculo, setModeloVehiculo] = useState("");
  const [nivelExperiencia, setNivelExperiencia] = useState("Novato");
  const [preferencias, setPreferencias] = useState({
    musica: true,
    fumar: false,
    mascotas: false,
    aire: true,
    charla: true,
  });
  const [verificaciones, setVerificaciones] = useState({
    email: true,
    telefono: true,
    dni: false,
    licencia: false,
  });

  const [modoLectura, setModoLectura] = useState(false);
  const [guardado, setGuardado] = useState(false);

  const reputacion = 4.8;
  const opiniones = 36;

  useEffect(() => {
    if (!usuario) return;
    const cargarDatos = async () => {
      const ref = doc(db, "usuarios", usuario.uid);
      const snap = await getDoc(ref);
      if (snap.exists()) {
        const data = snap.data();
        setWhatsapp(data.whatsapp || "");
        setFechaNacimiento(data.fechaNacimiento || "");
        setDescripcion(data.descripcion || "");
        setModeloVehiculo(data.modeloVehiculo || "");
        setNivelExperiencia(data.nivelExperiencia || "Novato");
        setPreferencias((prev) => ({ ...prev, ...data.preferencias }));
        setVerificaciones((prev) => ({ ...prev, ...data.verificaciones }));
        setModoLectura(true);
      }
    };
    cargarDatos();
  }, [usuario]);

  const calcularEdad = (fecha) => {
    if (!fecha) return "";
    const hoy = new Date();
    const nacimiento = new Date(fecha);
    let edad = hoy.getFullYear() - nacimiento.getFullYear();
    const m = hoy.getMonth() - nacimiento.getMonth();
    if (m < 0 || (m === 0 && hoy.getDate() < nacimiento.getDate())) edad--;
    return edad;
  };

  const edad = calcularEdad(fechaNacimiento);

  const guardarPerfil = async () => {
    const perfil = {
      nombre: usuario.displayName,
      fotoPerfil: usuario.photoURL,
      whatsapp,
      fechaNacimiento,
      descripcion,
      modeloVehiculo,
      nivelExperiencia,
      preferencias,
      verificaciones,
      rol: "conductor",
      verificado: verificaciones.dni && verificaciones.licencia,
      fechaRegistro: new Date(),
    };

    try {
      await setDoc(doc(db, "usuarios", usuario.uid), perfil, { merge: true });
      setGuardado(true);
      setModoLectura(true);
      setTimeout(() => setGuardado(false), 3000);
    } catch (e) {
      console.error("Error guardando perfil:", e);
      alert("Error al guardar. Intentá nuevamente.");
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white p-6 rounded-2xl shadow-md border mt-6">
      <div className="flex justify-end mb-4">
        {modoLectura && (
          <button
            onClick={() => setModoLectura(false)}
            className="w-full bg-blue-600 text-white py-2 rounded-xl hover:bg-blue-700 transition font-semibold shadow"
          >
            ✏️ Editar perfil
          </button>
        )}
      </div>

      <div className="flex items-center gap-4 mb-6">
        <img
          src={usuario?.photoURL}
          className="w-20 h-20 rounded-full object-cover border"
          alt="Perfil"
        />
        <div>
          <h2 className="text-xl font-bold">
            {usuario?.displayName}
            {edad && <span className="ml-2 text-sm text-gray-500">({edad} años)</span>}
          </h2>
          <p className="text-sm text-gray-700 mt-1">
            <strong>Nivel de conducción:</strong> {nivelExperiencia}
          </p>
          <div className="flex items-center gap-2 text-sm text-yellow-600">
            {"★".repeat(Math.floor(reputacion))}
            {reputacion % 1 >= 0.5 && "½"}
            <span className="text-gray-700">({opiniones} opiniones)</span>
          </div>
        </div>
      </div>

      {modoLectura ? (
        <>
          <p className="mb-2"><strong>WhatsApp:</strong> {whatsapp}</p>
          <p className="mb-2"><strong>Modelo del vehículo:</strong> {modeloVehiculo}</p>
          <p className="mb-2"><strong>Acerca de mí:</strong> {descripcion}</p>

          <div className="mb-4">
            <h4 className="font-semibold mb-2">Preferencias</h4>
            <ul className="list-disc list-inside text-sm text-gray-700">
              {Object.entries(preferencias)
                .filter(([, val]) => val)
                .map(([key]) => (
                  <li key={key}>
                    {{
                      musica: "Le gusta la música",
                      fumar: "Permite fumar",
                      mascotas: "Acepta mascotas",
                      aire: "Usa aire acondicionado",
                      charla: "Le gusta conversar",
                    }[key]}
                  </li>
                ))}
            </ul>
          </div>

          <div className="mb-4">
            <h4 className="font-semibold mb-2">Verificaciones</h4>
            <ul className="list-disc list-inside text-sm text-gray-700">
              {Object.entries(verificaciones)
                .filter(([, val]) => val)
                .map(([key]) => (
                  <li key={key}>
                    {{
                      email: "Correo confirmado",
                      telefono: "Teléfono confirmado",
                      dni: "DNI verificado",
                      licencia: "Licencia de conducir",
                    }[key]}
                  </li>
                ))}
            </ul>
          </div>
        </>
      ) : (
        <>
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700">WhatsApp</label>
            <input
              type="text"
              value={whatsapp}
              onChange={(e) => setWhatsapp(e.target.value)}
              className="w-full px-4 py-2 border rounded-xl shadow-sm"
            />
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700">Fecha de nacimiento</label>
            <input
              type="date"
              value={fechaNacimiento}
              onChange={(e) => setFechaNacimiento(e.target.value)}
              className="w-full px-4 py-2 border rounded-xl shadow-sm"
            />
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700">Nivel de experiencia</label>
            <select
              value={nivelExperiencia}
              onChange={(e) => setNivelExperiencia(e.target.value)}
              className="w-full px-4 py-2 border rounded-xl shadow-sm"
            >
              <option value="Novato">Novato</option>
              <option value="Experimentado">Experimentado</option>
              <option value="Embajador">Embajador</option>
              <option value="Super Driver">Super Driver</option>
            </select>
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700">Modelo del vehículo</label>
            <input
              type="text"
              value={modeloVehiculo}
              onChange={(e) => setModeloVehiculo(e.target.value)}
              className="w-full px-4 py-2 border rounded-xl shadow-sm"
            />
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700">Acerca de mí</label>
            <textarea
              rows="4"
              value={descripcion}
              onChange={(e) => setDescripcion(e.target.value)}
              className="w-full px-4 py-2 border rounded-xl shadow-sm"
            ></textarea>
          </div>

          <div className="mb-4">
            <h4 className="text-sm font-semibold mb-2">Preferencias de viaje</h4>
            <div className="grid grid-cols-2 gap-2 text-sm text-gray-700">
              {Object.entries(preferencias).map(([key, val]) => (
                <label key={key} className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    name={key}
                    checked={val}
                    onChange={(e) =>
                      setPreferencias((prev) => ({
                        ...prev,
                        [key]: e.target.checked,
                      }))
                    }
                  />
                  {{
                    musica: "Le gusta la música",
                    fumar: "Permite fumar",
                    mascotas: "Acepta mascotas",
                    aire: "Usa aire acondicionado",
                    charla: "Le gusta conversar",
                  }[key]}
                </label>
              ))}
            </div>
          </div>

          <div className="mb-4">
            <h4 className="text-sm font-semibold mb-2">Verificaciones</h4>
            <div className="grid grid-cols-2 gap-2 text-sm text-gray-700">
              {Object.entries(verificaciones).map(([key, val]) => (
                <label key={key} className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    name={key}
                    checked={val}
                    onChange={(e) =>
                      setVerificaciones((prev) => ({
                        ...prev,
                        [key]: e.target.checked,
                      }))
                    }
                  />
                  {{
                    email: "Correo confirmado",
                    telefono: "Teléfono confirmado",
                    dni: "DNI verificado",
                    licencia: "Licencia de conducir",
                  }[key]}
                </label>
              ))}
            </div>
          </div>

          <button
            onClick={guardarPerfil}
            className="w-full bg-blue-600 text-white py-2 rounded-xl hover:bg-blue-700 transition font-semibold shadow"
          >
            💾 Guardar Perfil
          </button>
        </>
      )}

      {guardado && (
        <p className="text-green-600 text-center mt-2">
          ✅ Perfil guardado con éxito
        </p>
      )}
    </div>
  );
}
