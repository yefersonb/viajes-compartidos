// src/components/NuevoViaje.js
import React, { useState, useEffect } from "react";
import { auth, db } from "../firebase";
import { collection, addDoc, doc, getDoc } from "firebase/firestore";
import AutocompleteInput from "./AutocompleteInput";

export default function NuevoViaje() {
  const [origen, setOrigen] = useState("");
  const [destino, setDestino] = useState("");

  const getDefaultDateTime = () => {
    const now = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    const fecha = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
    const hora = `${pad(now.getHours())}:${pad(now.getMinutes())}`;
    return `${fecha}T${hora}`;
  };
  const [fechaHora, setFechaHora] = useState(getDefaultDateTime());
  const [asientos, setAsientos] = useState(1);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!origen && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async ({ coords }) => {
          const key = process.env.REACT_APP_GOOGLE_MAPS_API_KEY;
          try {
            const res = await fetch(
              `https://maps.googleapis.com/maps/api/geocode/json?latlng=${coords.latitude},${coords.longitude}&key=${key}`
            );
            const json = await res.json();
            let raw = json.results?.[0]?.formatted_address || "Ubicación detectada";
            const clean = raw.replace(/^[A-Z0-9]{4}\+[A-Z0-9]{2},\s*/, "");
            setOrigen({
              formatted_address: clean,
              geometry: {
                location: { lat: () => coords.latitude, lng: () => coords.longitude }
              }
            });
          } catch (e) {
            console.warn("Reverse geocoding error", e);
            setOrigen({ formatted_address: "Ubicación detectada", geometry: { location: { lat: () => coords.latitude, lng: () => coords.longitude } } });
          }
        },
        (err) => console.warn("GPS error", err)
      );
    }
  }, [origen]);

  const inputStyle = {
    width: "100%",
    padding: "0.5rem",
    margin: "0.5rem 0",
    border: "1px solid #ccc",
    borderRadius: "0.5rem",
    fontFamily: "inherit",
    fontSize: "1rem",
  };

  const publicarViaje = async () => {
    if (!auth.currentUser) return alert("⚠️ Iniciá sesión para publicar.");
    if (!origen || !destino || !fechaHora) return alert("Completá todos los campos.");
    setLoading(true);
    try {
      const ref = doc(db, "usuarios", auth.currentUser.uid);
      const snap = await getDoc(ref);
      if (!snap.exists()) throw new Error("Usuario no en Firestore");
      const u = snap.data();
      if (!u.nombre || !u.whatsapp) throw new Error("Datos incompletos");

      const oStr = origen.formatted_address;
      const dStr = destino.formatted_address;
      const oCoords = { lat: origen.geometry.location.lat(), lng: origen.geometry.location.lng() };
      const dCoords = destino.geometry?.location ? { lat: destino.geometry.location.lat(), lng: destino.geometry.location.lng() } : null;
      const [f] = fechaHora.split("T");

      await addDoc(collection(db, "viajes"), { origen: oStr, destino: dStr, origenCoords: oCoords, destinoCoords: dCoords, fecha: f, horario: fechaHora, asientos, creado: new Date(), conductor: { uid: auth.currentUser.uid, nombre: u.nombre, whatsapp: u.whatsapp } });
      alert("✅ Viaje publicado");
      setOrigen(""); setDestino(""); setFechaHora(getDefaultDateTime()); setAsientos(1);
    } catch (e) {
      console.error(e);
      alert(e.message.includes("Usuario") ? "Usuario no registrado" : "Error al publicar");
    }
    setLoading(false);
  };

  const incompleto = !origen || !destino || !fechaHora || asientos < 1;

  return (
    <section style={{ padding: "1rem" }}>
      <h3 style={{ fontSize: "1.125rem", fontWeight: 600, marginBottom: "0.75rem" }}>Crear Nuevo Viaje</h3>
      <AutocompleteInput placeholder="Origen" value={origen.formatted_address || origen} onChange={setOrigen} />
      <AutocompleteInput placeholder="Destino" value={destino.formatted_address || destino} onChange={setDestino} />
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', margin: '0.5rem 0' }}>
        <input
          type="datetime-local"
          value={fechaHora}
          onChange={e => setFechaHora(e.target.value)}
          style={inputStyle}
        />
        {fechaHora.split('T')[0] === new Date().toISOString().slice(0, 10) && (
          <span style={{ fontSize: '0.875rem', color: '#555' }}>Hoy</span>
        )}
      </div>
      <input type="number" min={1} value={asientos} onChange={e=>setAsientos(+e.target.value)} style={inputStyle} />
      <button
        onClick={publicarViaje}
        disabled={incompleto || loading}
        className="btn-rounded highlight-hover"
        style={{ width: "100%" }}
      >
        {loading ? "Publicando..." : "Publicar Viaje"}
      </button>
    </section>
  );
}
