// src/components/DetalleViaje.js
import React, { useEffect, useRef, useState } from "react";

const viajeDePrueba = {
  id: "demo-1",
  origen: "Montecarlo, Misiones, Argentina",
  destino: "Posadas, Misiones, Argentina",
  valor: 3500,
};

export default function DetalleViaje({
  viaje = viajeDePrueba,
  onReservar = (id) => alert(`Reserva de prueba confirmada: ${id}`),
}) {
  const mapRef = useRef(null);
  const [info, setInfo] = useState({ distancia: "", duracion: "" });
  const [error, setError] = useState("");

  useEffect(() => {
    if (!window.google) {
      setError("❗ La API de Google Maps no se cargó.");
      return;
    }

    const service = new window.google.maps.DirectionsService();
    const renderer = new window.google.maps.DirectionsRenderer();
    const map = new window.google.maps.Map(mapRef.current, {
      zoom: 7,
      center: { lat: -27.3671, lng: -55.8961 },
    });
    renderer.setMap(map);

    service.route(
      {
        origin: viaje.origen,
        destination: viaje.destino,
        travelMode: window.google.maps.TravelMode.DRIVING,
      },
      (result, status) => {
        if (status === "OK") {
          renderer.setDirections(result);
          const leg = result.routes[0].legs[0];
          setInfo({
            distancia: leg.distance.text,
            duracion: leg.duration.text,
          });
        } else {
          setError("No se pudo calcular la ruta.");
        }
      }
    );
  }, [viaje]);

  return (
    <div style={{ maxWidth: 600, margin: "auto", padding: "1rem" }}>
      {error ? (
        <p style={{ color: "red" }}>{error}</p>
      ) : (
        <>
          <div
            ref={mapRef}
            style={{
              width: "100%",
              height: "300px",
              borderRadius: 8,
              boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
            }}
          />
          <p>
            <strong>Distancia:</strong> {info.distancia} <br />
            <strong>Duración estimada:</strong> {info.duracion}
          </p>
          <p>
            <strong>Valor del viaje:</strong> ${viaje.valor}
          </p>
          <button
            onClick={() => onReservar(viaje.id)}
            style={{
              padding: "0.5rem 1rem",
              background: "#28a745",
              color: "#fff",
              border: "none",
              borderRadius: 4,
              cursor: "pointer",
            }}
          >
            Confirmar reserva
          </button>
        </>
      )}
    </div>
  );
}
