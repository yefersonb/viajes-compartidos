import React, { useState } from "react";
import { auth, db } from "../firebase";
import {
  collection,
  query,
  where,
  getDocs,
  doc,
  updateDoc,
  increment,
  addDoc,
} from "firebase/firestore";
import AutoResults from "./AutoResults";

export default function BuscadorViajes() {
  const [origen, setOrigen] = useState("");
  const [destino, setDestino] = useState("");
  const [viajes, setViajes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleBuscar = async () => {
    setError("");
    if (!origen || !destino) {
      setError("Por favor completá origen y destino.");
      return;
    }
    setLoading(true);
    try {
      const q = query(
        collection(db, "viajes"),
        where("origen", "==", origen),
        where("destino", "==", destino)
      );
      const snap = await getDocs(q);
      const lista = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      setViajes(lista);
      if (!lista.length) setError("No se encontraron viajes.");
    } catch (e) {
      console.error(e);
      setError("Error al buscar viajes.");
    }
    setLoading(false);
  };

  const reservarViaje = async (id) => {
    if (!auth.currentUser) {
      setError("Tenés que iniciar sesión para reservar.");
      return;
    }
    setLoading(true);
    try {
      const ref = doc(db, "viajes", id);
      await updateDoc(ref, { asientosDisponibles: increment(-1) });
      await addDoc(collection(db, "reservas"), {
        viajeId: id,
        userId: auth.currentUser.uid,
        timestamp: new Date(),
      });
      setViajes((vs) =>
        vs.map((v) =>
          v.id === id
            ? { ...v, asientosDisponibles: v.asientosDisponibles - 1 }
            : v
        )
      );
      // aquí ya no hay ningún alert
    } catch (e) {
      console.error(e);
      setError("Hubo un error al procesar la reserva.");
    }
    setLoading(false);
  };

  return (
    <div style={{ maxWidth: 600, margin: "auto", padding: "1rem" }}>
      <h2>🔍 Buscar viaje</h2>

      <input
        placeholder="Origen"
        value={origen}
        onChange={(e) => setOrigen(e.target.value)}
        style={{ width: "100%", padding: 8, marginBottom: 8 }}
      />
      <input
        placeholder="Destino"
        value={destino}
        onChange={(e) => setDestino(e.target.value)}
        style={{ width: "100%", padding: 8, marginBottom: 8 }}
      />

      {error && <p style={{ color: "red", marginBottom: 8 }}>{error}</p>}

      <button
        onClick={handleBuscar}
        disabled={loading}
        style={{
          padding: "0.5rem 1rem",
          background: "#007bff",
          color: "#fff",
          border: "none",
          borderRadius: 4,
          cursor: loading ? "not-allowed" : "pointer",
        }}
      >
        {loading ? "Buscando…" : "Buscar"}
      </button>

      <hr style={{ margin: "1.5rem 0" }} />

      {/* Aquí ya no hay map(viajes=>…) manual: */}
      <AutoResults viajes={viajes} onReservar={reservarViaje} />
    </div>
  );
}
