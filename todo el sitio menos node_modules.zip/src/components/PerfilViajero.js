import React from "react";

// Componente PerfilViajero deshabilitado: ya no se requiere completar perfil para cambiar de rol.
export default function PerfilViajero() {
  return null;
}
