import React from "react";
import { GoogleMap, Marker, useJsApiLoader } from "@react-google-maps/api";
import "./DetalleViaje.css";

export default function DetalleViaje({ viaje, onReservar, onClose }) {
  const { isLoaded } = useJsApiLoader({
    googleMapsApiKey: process.env.REACT_APP_GOOGLE_MAPS_API_KEY,
    libraries: ['places'],
  });

  // Evitar error si coordenadas no están definidas
  const lat = viaje?.origenCoords?.lat;
  const lng = viaje?.origenCoords?.lng;
  const center = lat && lng ? { lat, lng } : null;

  if (!viaje) return null;

  return (
    <div className="dv-overlay" onClick={onClose}>
      <div className="dv-modal" onClick={(e) => e.stopPropagation()}>
        <button className="dv-close" onClick={onClose}>×</button>
        <h2>Detalle de Viaje</h2>
        {isLoaded && center ? (
          <GoogleMap
            mapContainerStyle={{ width: '100%', height: '300px' }}
            center={center}
            zoom={12}
          >
            <Marker position={center} />
          </GoogleMap>
        ) : (
          <p>Cargando mapa...</p>
        )}
        <div style={{ marginTop: '1rem' }}>
          <p><strong>Origen:</strong> {viaje.origen}</p>
          <p><strong>Destino:</strong> {viaje.destino}</p>
          <p><strong>Horario:</strong> {viaje.horario}</p>
          <p><strong>Asientos disponibles:</strong> {viaje.asientos}</p>
        </div>
        <div className="dv-actions">
          <button onClick={onClose}>Volver</button>
          <button
            onClick={() => onReservar(viaje.id)}
            disabled={viaje.asientos <= 0}
          >
            {viaje.asientos > 0 ? 'Confirmar Reserva' : 'Sin asientos'}
          </button>
        </div>
      </div>
    </div>
  );
}
