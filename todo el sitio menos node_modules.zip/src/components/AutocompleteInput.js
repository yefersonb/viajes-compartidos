// src/components/AutocompleteInput.js
import React, { useRef, useState, useEffect } from "react";
import { useJsApiLoader } from "@react-google-maps/api";

const libraries = ["places"];

export default function AutocompleteInput({ placeholder, value, onChange }) {
  const { isLoaded, loadError } = useJsApiLoader({
    googleMapsApiKey: process.env.REACT_APP_GOOGLE_MAPS_API_KEY,
    libraries,
  });
  const inputRef = useRef(null);

  useEffect(() => {
    if (isLoaded && !loadError && inputRef.current) {
      const autocomplete = new window.google.maps.places.Autocomplete(
        inputRef.current,
        { types: ["geocode"] }
      );
      autocomplete.setFields(["formatted_address"]);
      autocomplete.addListener("place_changed", () => {
        const place = autocomplete.getPlace();
        onChange(place.formatted_address);
      });
    }
  }, [isLoaded, loadError, onChange]);

  if (loadError) return <p>Error cargando Autocomplete</p>;
  if (!isLoaded) return <p>Cargando Autocomplete…</p>;

  return (
    <input
      ref={inputRef}
      type="text"
      placeholder={placeholder}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      style={{ width: "100%", padding: 8, margin: "8px 0" }}
    />
  );
}
