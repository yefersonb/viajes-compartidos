// Constantes únicas para toda la app
export const MAP_LIBS      = ["places", "geometry"]; 
export const MAP_LOADER_ID = "google-map-script";